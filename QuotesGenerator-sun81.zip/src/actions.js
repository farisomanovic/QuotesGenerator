import { HttpError } from 'wasp/server'

export const addFavoriteQuote = async ({ quoteId }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const quote = await context.entities.Quote.findUnique({
    where: { id: quoteId }
  });
  
  if (!quote) { throw new HttpError(404, 'Quote not found') }

  await context.entities.User.update({
    where: { id: context.user.id },
    data: { favoriteQuotes: { connect: { id: quoteId } } }
  });

  const updatedUser = await context.entities.User.findUnique({
    where: { id: context.user.id },
    include: { favoriteQuotes: true }
  });

  return updatedUser.favoriteQuotes;
}
