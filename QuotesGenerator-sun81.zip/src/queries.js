import { HttpError } from 'wasp/server'

export const generateQuote = async (args, context) => {
  const quoteCount = await context.entities.Quote.count();
  const randomIndex = Math.floor(Math.random() * quoteCount);
  const randomQuote = await context.entities.Quote.findMany({
    skip: randomIndex,
    take: 1,
    select: {
      text: true,
      author: true,
      category: true
    }
  });
  return randomQuote[0];
}

export const getFavoriteQuotes = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }
  return context.entities.Quote.findMany({
    where: {
      favoritedBy: { some: { id: context.user.id } }
    }
  });
}
