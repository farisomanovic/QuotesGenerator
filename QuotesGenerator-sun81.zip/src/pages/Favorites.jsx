import React from 'react';
import { useQuery } from 'wasp/client/operations';
import { getFavoriteQuotes } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const FavoritesPage = () => {
  const { data: favoriteQuotes, isLoading, error } = useQuery(getFavoriteQuotes);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className="p-4 bg-white rounded-lg">
      <h1 className="text-2xl font-bold mb-4">My Favorite Quotes</h1>
      <div className="space-y-4">
        {favoriteQuotes.map((quote) => (
          <div
            key={quote.id}
            className="p-4 bg-gray-100 rounded-md hover:shadow-lg transition-shadow"
          >
            <p className="text-lg font-semibold">{quote.text}</p>
            <p className="text-sm italic mt-2">- {quote.author || 'Unknown'}</p>
            <p className="text-sm text-gray-500 mt-1">Category: {quote.category}</p>
          </div>
        ))}
      </div>
      <Link to="/" className="text-blue-500 hover:underline mt-4 inline-block">Go to Quote Generator</Link>
    </div>
  );
}

export default FavoritesPage;
