import React, { useState } from 'react';
import { useQuery, useAction, generateQuote, addFavoriteQuote } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const QuotesGeneratorPage = () => {
  const { data: quote, refetch, isLoading } = useQuery(generateQuote);
  const addFavoriteQuoteFn = useAction(addFavoriteQuote);
  const [bgColor, setBgColor] = useState('bg-white');

  const changeBgColor = () => {
    const colors = ['bg-white', 'bg-blue-100', 'bg-yellow-100', 'bg-pink-100', 'bg-green-100'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    setBgColor(randomColor);
  };

  const handleNewQuote = () => {
    refetch();
    changeBgColor();
  };

  const handleAddFavorite = async () => {
    if (quote) {
      await addFavoriteQuoteFn({ quoteId: quote.id });
      alert('Quote added to favorites!');
    }
  };

  return (
    <div className={`flex flex-col items-center justify-center h-screen ${bgColor}`}>
      <div className="p-6 bg-white rounded-lg shadow-lg animate-fadeIn transition duration-500">
        {isLoading ? (
          <p>Loading...</p>
        ) : (
          quote && (
            <>
              <p className="text-xl font-semibold">"{quote.text}"</p>
              <p className="text-sm text-gray-600 mt-2">- {quote.author || 'Unknown'}</p>
              <p className="text-sm text-gray-500 mt-2 italic">Category: {quote.category}</p>
            </>
          )
        )}
      </div>
      <div className="mt-4">
        <button
          onClick={handleNewQuote}
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-2"
        >
          New Quote
        </button>
        <button
          onClick={handleAddFavorite}
          className="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded"
        >
          Add to Favorites
        </button>
        <Link
          to="/favorites"
          className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded ml-2"
        >
          View Favorites
        </Link>
      </div>
    </div>
  );
};

export default QuotesGeneratorPage;
